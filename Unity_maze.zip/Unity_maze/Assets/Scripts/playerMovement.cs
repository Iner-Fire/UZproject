﻿using UnityEngine;
public class playerMovement : MonoBehaviour
{
    public float MovementSpeed;
    private Rigidbody2D rigibody;
    private Vector2 moveVelocity;
    public Rigidbody2D rb;
    public float hp;
    Vector3 mv;
    // Start is called before the first frame update
    void Start()
    {
        rigibody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        moveVelocity = moveInput.normalized * MovementSpeed;
    }
    void FixedUpdate()
    {
        rigibody.MovePosition(rigibody.position + moveVelocity * Time.fixedDeltaTime);
        rb.velocity = new Vector2(mv.x, mv.y);
    }
   private void OnCollisionEnter2D(Collision2D collision)
    {
      /* hp -= 5;
        if (hp<=0)
        {
            Destroy(GameObject.FindGameObjectWithTag("Player"));
        }*/
    }
   private void OnCollisionExit2D(Collision2D collision)
    {
        Debug.Log("Exit");
   }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(GameObject.FindGameObjectWithTag("Glue"))
        MovementSpeed /= 3;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (GameObject.FindGameObjectWithTag("Glue"))
        {
            MovementSpeed *= 3;
        }
       
    }
}